package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoBreakApplicationTests {

	@Test
	void contextLoads() {
		System.out.println("it is done");
	}

}
