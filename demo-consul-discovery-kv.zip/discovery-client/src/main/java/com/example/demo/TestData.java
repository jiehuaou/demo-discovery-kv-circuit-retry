package com.example.demo;

import org.springframework.stereotype.Component;

@Component
public class TestData {
    String value = "undefined";

    String valueId = "abc";
}