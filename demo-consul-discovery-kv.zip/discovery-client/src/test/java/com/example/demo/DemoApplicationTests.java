package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;



class DemoApplicationTests {

	@Test
	void testRandom() {
		DiscoveryClientController dis = new DiscoveryClientController();
		for (int i = 0; i < 10; i++) {
			int index = dis.random(10);
			assertTrue(index >= 0);
			System.out.println("index : " + index);
		}
	}

}
